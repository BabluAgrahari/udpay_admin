/**
 * Form Basic Inputs
 */

'use strict';

(function () {
  // Indeterminate checkbox
  const checkbox = document.getElementById('defaultCheck2');
  checkbox.indeterminate = true;
})();
