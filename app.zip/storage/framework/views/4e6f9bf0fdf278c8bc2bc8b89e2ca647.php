

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card">
            <div class="row card-header">
                <div class="col-md-10">
                    <h5>User Details - <?php echo e($user->full_name ?? ($user->first_name . ' ' . $user->last_name)); ?></h5>
                </div>
                <div class="col-md-2 text-right">
                    <a href="<?php echo e(url('crm/user')); ?>" class="btn btn-outline-warning btn-sm">
                        <i class='bx bx-left-arrow-circle' style="line-height: 0"></i>&nbsp;Back
                    </a>
                </div>
            </div>

            <div class="card-body">
                <!-- Basic User Information -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h6 class="text-primary"><i class="bx bx-user"></i> Basic Information</h6>
                        <hr>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <th width="30%">User ID:</th>
                                <td><?php echo e($user->user_id ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Reference ID:</th>
                                <td><?php echo e($user->ref_id ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Username:</th>
                                <td><?php echo e($user->user_nm ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Alpha Numeric UID:</th>
                                <td><?php echo e($user->alpha_num_uid ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Full Name:</th>
                                <td><?php echo e($user->full_name ?? ($user->first_name . ' ' . $user->last_name)); ?></td>
                            </tr>
                            <tr>
                                <th>Email:</th>
                                <td><?php echo e($user->email ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Mobile:</th>
                                <td><?php echo e($user->mobile ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Role:</th>
                                <td>
                                    <span class="badge bg-label-<?php echo e($user->role == 'admin' ? 'danger' : ($user->role == 'merchant' ? 'warning' : ($user->role == 'customer' ? 'info' : 'secondary'))); ?>">
                                        <?php echo e(ucwords($user->role ?? 'N/A')); ?>

                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th>Status:</th>
                                <td><?php echo status($user->isactive); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <th width="30%">Date of Birth:</th>
                                <td><?php echo e($user->dob ? $user->dFormat($user->dob) : 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Gender:</th>
                                <td><?php echo e(ucwords($user->gender ?? 'N/A')); ?></td>
                            </tr>
                            <tr>
                                <th>Created On:</th>
                                <td><?php echo e($user->dFormat($user->created)); ?></td>
                            </tr>
                            <tr>
                                <th>Last Updated:</th>
                                <td><?php echo e($user->updated ? $user->dFormat($user->updated) : 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Modified On:</th>
                                <td><?php echo e($user->modified_on ? $user->dFormat($user->modified_on) : 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Upgrade Date:</th>
                                <td><?php echo e($user->upgrade_date ? $user->dFormat($user->upgrade_date) : 'N/A'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- System Settings -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h6 class="text-primary"><i class="bx bx-cog"></i> System Settings</h6>
                        <hr>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <th width="30%">Restricted:</th>
                                <td>
                                    <?php if($user->restricted == 1): ?>
                                        <span class="badge bg-danger">Yes</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">No</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>User Flag:</th>
                                <td>
                                    <?php if($user->uflag == 1): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Royalty:</th>
                                <td><?php echo e($user->royalty ?? 0); ?></td>
                            </tr>
                            <tr>
                                <th>Plan Membership:</th>
                                <td><?php echo e($user->planMem ?? 0); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <th width="30%">Verification Code:</th>
                                <td><?php echo e($user->vercode ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Verification Code 1:</th>
                                <td><?php echo e($user->vercode1 ?? 'N/A'); ?></td>
                            </tr>
                            
                            <tr>
                                <th>E-PIN:</th>
                                <td><?php echo e($user->epin ?? 'N/A'); ?></td>
                            </tr>
                            
                        </table>
                    </div>
                </div>

                <!-- KYC Information -->
                <?php if($user->kyc): ?>
                <div class="row mb-4">
                    <div class="col-12">
                        <h6 class="text-primary"><i class="bx bx-id-card"></i> KYC Information</h6>
                        <hr>
                    </div>
                </div>

                <!-- KYC Status -->
                <div class="row mb-3">
                    <div class="col-12">
                        <div class="alert alert-info">
                            <div class="row">
                                <div class="col-md-3">
                                    <strong>KYC Status:</strong>
                                    <?php if($user->kyc->kyc_flag == 1): ?>
                                        <span class="badge bg-success">Verified</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Pending Verification</span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3">
                                    <strong>Personal Details:</strong>
                                    <?php if($user->kyc->personal_flag == 1): ?>
                                        <span class="badge bg-success">Complete</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Incomplete</span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3">
                                    <strong>Bank Details:</strong>
                                    <?php if($user->kyc->bank_flag == 1): ?>
                                        <span class="badge bg-success">Complete</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Incomplete</span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3">
                                    <strong>Documents:</strong>
                                    <?php if($user->kyc->pan_front || $user->kyc->aadhar_front): ?>
                                        <span class="badge bg-success">Uploaded</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Missing</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Personal Details -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6 class="text-secondary">Personal Details</h6>
                        <table class="table table-borderless">
                            <tr>
                                <th width="40%">Full Name:</th>
                                <td><?php echo e($user->kyc->name ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Mobile Number:</th>
                                <td><?php echo e($user->kyc->mobile_no ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Date of Birth:</th>
                                <td><?php echo e($user->kyc->dob ? date('d M, Y', strtotime($user->kyc->dob)) : 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Gender:</th>
                                <td><?php echo e(ucwords($user->kyc->gender ?? 'N/A')); ?></td>
                            </tr>
                            <tr>
                                <th>PAN Number:</th>
                                <td><?php echo e($user->kyc->pan_no ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Aadhar Number:</th>
                                <td><?php echo e($user->kyc->aadhar_no ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Occupation:</th>
                                <td><?php echo e($user->kyc->work ?? 'N/A'); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-secondary">Address Details</h6>
                        <table class="table table-borderless">
                            <tr>
                                <th width="40%">Address:</th>
                                <td><?php echo e($user->kyc->address ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Locality:</th>
                                <td><?php echo e($user->kyc->locality ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>District:</th>
                                <td><?php echo e($user->kyc->district ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>State:</th>
                                <td><?php echo e($user->kyc->state ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Pincode:</th>
                                <td><?php echo e($user->kyc->pincode ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>ID Proof Type:</th>
                                <td><?php echo e($user->kyc->id_proof ?? 'N/A'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- Bank Details -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6 class="text-secondary">Bank Details</h6>
                        <table class="table table-borderless">
                            <tr>
                                <th width="40%">Bank Name:</th>
                                <td><?php echo e($user->kyc->bank ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Account Number:</th>
                                <td><?php echo e($user->kyc->account_number ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>IFSC Code:</th>
                                <td><?php echo e($user->kyc->ifsc_code ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Branch:</th>
                                <td><?php echo e($user->kyc->branch ?? 'N/A'); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-secondary">Nominee Details</h6>
                        <table class="table table-borderless">
                            <tr>
                                <th width="40%">Nominee Name:</th>
                                <td><?php echo e($user->kyc->nominee ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Relation:</th>
                                <td><?php echo e($user->kyc->relation ?? 'N/A'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- Documents -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h6 class="text-secondary">Documents</h6>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <i class="bx bx-file-pdf" style="font-size: 2rem; color: #dc3545;"></i>
                                        <p class="mb-1"><strong>PAN Front</strong></p>
                                        <?php if($user->kyc->pan_front): ?>
                                            <a href="<?php echo e($user->kyc->pan_front); ?>" target="_blank" class="btn btn-sm btn-outline-primary">View</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <i class="bx bx-file-pdf" style="font-size: 2rem; color: #198754;"></i>
                                        <p class="mb-1"><strong>Aadhar Front</strong></p>
                                        <?php if($user->kyc->aadhar_front): ?>
                                            <a href="<?php echo e($user->kyc->aadhar_front); ?>" target="_blank" class="btn btn-sm btn-outline-primary">View</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <i class="bx bx-file-pdf" style="font-size: 2rem; color: #198754;"></i>
                                        <p class="mb-1"><strong>Aadhar Back</strong></p>
                                        <?php if($user->kyc->aadhar_back): ?>
                                            <a href="<?php echo e($user->kyc->aadhar_back); ?>" target="_blank" class="btn btn-sm btn-outline-primary">View</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <i class="bx bx-file-pdf" style="font-size: 2rem; color: #0d6efd;"></i>
                                        <p class="mb-1"><strong>Bank Document</strong></p>
                                        <?php if($user->kyc->bank_doc): ?>
                                            <a href="<?php echo e($user->kyc->bank_doc); ?>" target="_blank" class="btn btn-sm btn-outline-primary">View</a>
                                        <?php else: ?>
                                            <span class="text-muted">Not uploaded</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="alert alert-warning">
                            <h6><i class="bx bx-info-circle"></i> KYC Information</h6>
                            <p class="mb-0">No KYC information has been submitted for this user.</p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="<?php echo e(url('crm/user/' . $user->_id . '/edit')); ?>" class="btn btn-primary">
                            <i class="bx bx-edit"></i> Edit User
                        </a>
                        <a href="<?php echo e(url('crm/user/' . $user->_id . '/kyc')); ?>" class="btn btn-info">
                            <i class="bx bx-id-card"></i> Manage KYC
                        </a>
                        <a href="<?php echo e(url('crm/user')); ?>" class="btn btn-secondary">
                            <i class="bx bx-arrow-back"></i> Back to List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('CRM.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\CRM\User\show.blade.php ENDPATH**/ ?>