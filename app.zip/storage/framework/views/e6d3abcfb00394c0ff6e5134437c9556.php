<div class="row mb-2" id="filter" <?= empty($filter) ? "style='display:none'" : '' ?>>

    <div class="col-md-12 ml-auto">

        <form action="<?php echo e(url('crm/loan')); ?>">

            <div class="row">



                <div class="col-md-3 mb-3">

                    <label>Name</label>

                    <input type="text" class="form-control form-control-sm" name="employee_name"
                        value="<?php echo e(!empty($filter['employee_name']) ? $filter['employee_name'] : ''); ?>"
                        placeholder="Enter Employee Name">

                </div>

                <div class="col-md-2 mb-3">

                    <label>Status</label>

                    <select class="form-select form-select-sm" name="status">

                        <option value="">All</option>

                        <option value="pending" <?php if(!empty($filter['status']) && $filter['status'] == 'pending'): echo 'selected'; endif; ?>>
                            Pending</option>

                        <option value="on_going" <?php if(!empty($filter['status']) && $filter['status'] == 'on_going'): echo 'selected'; endif; ?>>
                            On Going</option>

                        <option value="completed" <?php if(!empty($filter['status']) && $filter['status'] == 'completed'): echo 'selected'; endif; ?>>Completed</option>

                    </select>

                </div>

                <div class="col-md-3 mt-4">

                    <button type="submit" class="btn btn-outline-primary btn-sm"><i
                            class="fas fa-search"></i>&nbsp;Search</button>

                    <a href="<?php echo e(url('crm/loan')); ?>" class="btn btn-outline-danger btn-sm"><i
                            class="fas fa-eraser"></i>&nbsp;Clear</a>

                </div>

            </div>

        </form>

    </div>

</div><?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\CRM\User\filter.blade.php ENDPATH**/ ?>