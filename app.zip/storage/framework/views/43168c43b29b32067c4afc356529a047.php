
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <div class="row card-header">
            <div class="col-md-10">
                <h5>Products</h5>
            </div>
            <div class="col-md-2 text-right">
                <a href="<?php echo e(url('crm/products/create')); ?>" class="btn btn-primary btn-sm">
                    <i class='bx bx-plus'></i>&nbsp;Add New
                </a>
            </div>
        </div>

        <div class="card-body">
            <form action="<?php echo e(url('crm/products')); ?>" method="GET" class="mb-3">
                <div class="row">
                    <div class="col-md-3">
                        <input type="text" name="search" class="form-control" placeholder="Search..." value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-3">
                        <select name="category_id" class="form-select">
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->_id); ?>" <?php echo e(request('category_id') == $category->_id ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="status" class="form-select">
                            <option value="">Select Status</option>
                            <option value="1" <?php echo e(request('status') === '1' ? 'selected' : ''); ?>>Active</option>
                            <option value="0" <?php echo e(request('status') === '0' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="<?php echo e(url('crm/products')); ?>" class="btn btn-secondary">Reset</a>
                    </div>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>SKU</th>
                            <th>Category</th>
                            <th>MRP</th>
                            <th>Sale Price</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php if($product->images && count($product->images) > 0): ?>
                                    <img src="<?php echo e(asset($product->images[0])); ?>" alt="<?php echo e($product->product_name); ?>" style="max-width: 50px;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="No Image" style="max-width: 50px;">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($product->product_name); ?></td>
                            <td><?php echo e($product->sku); ?></td>
                            <td><?php echo e($product->category->name ?? 'N/A'); ?></td>
                            <td><?php echo e(number_format($product->mrp, 2)); ?></td>
                            <td><?php echo e(number_format($product->sale_price, 2)); ?></td>
                            <td><?php echo e($product->stock); ?></td>
                            <td>
                                <div class="form-check form-switch">
                                    <input type="checkbox" class="form-check-input status-switch" 
                                        id="status<?php echo e($product->_id); ?>" 
                                        data-id="<?php echo e($product->_id); ?>"
                                        <?php echo e($product->status ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="status<?php echo e($product->_id); ?>"></label>
                                </div>
                            </td>
                            <td>
                                <a href="<?php echo e(url('crm/products/'.$product->_id.'/edit')); ?>" class="btn btn-sm btn-icon btn-outline-primary">
                                    <i class='bx bx-edit'></i>
                                </a>
                                <button type="button" class="btn btn-sm btn-icon btn-outline-danger delete-btn" data-id="<?php echo e($product->_id); ?>">
                                    <i class='bx bx-trash'></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center">No products found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
$(document).ready(function() {
    // Status switch handler
    $('.status-switch').change(function() {
        const id = $(this).data('id');
        const status = $(this).prop('checked');
        
        $.ajax({
            url: '<?php echo e(url("crm/products/update-status")); ?>',
            method: 'POST',
            data: {
                id: id,
                status: status,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                alertMsg(response.status, response.msg, 3000);
            },
            error: function(xhr) {
                alertMsg(false, xhr.responseJSON.msg || 'An error occurred while updating status.', 3000);
            }
        });
    });

    // Delete handler
    $('.delete-btn').click(function() {
        const id = $(this).data('id');
        
        if (confirm('Are you sure you want to delete this product?')) {
            $.ajax({
                url: `/crm/products/${id}`,
                method: 'DELETE',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    alertMsg(response.status, response.msg, 3000);
                    if (response.status) {
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    }
                },
                error: function(xhr) {
                    alertMsg(false, xhr.responseJSON.msg || 'An error occurred while deleting the product.', 3000);
                }
            });
        }
    });
});
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('CRM.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\CRM\product\index.blade.php ENDPATH**/ ?>