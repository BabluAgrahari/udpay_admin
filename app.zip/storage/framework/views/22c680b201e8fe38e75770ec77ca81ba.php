<form id="saveBank" method="post" action="<?php echo e(url('crm/save-bank')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="mb-4 col-md-4">
            <label>Account Holder Name<span class="text-danger"><b>*</b></span></label>
            <input type="text" class="form-control" id="holder_name" name="bank_details[holder_name]" value="<?php echo e($record->bank_details['holder_name']??''); ?>" placeholder="Enter Account Holder Name">
            <span class="msg text-danger" id="bank_details_holder_name_msg"></span>
        </div>

        <div class="mb-4 col-md-4">
            <label>Bank Name <span class="text-danger"><b>*</b></span></label>
            <input type="text" class="form-control" id="bank_name" name="bank_details[bank_name]" value="<?php echo e($record->bank_details['bank_name']??''); ?>" placeholder="Enter Bank Name">
            <span class="msg text-danger" id="bank_details_bank_name_msg"></span>
        </div>

        <div class="mb-4 col-md-4">
            <label>Account No <span class="text-danger"><b>*</b></span></label>
            <input type="text" class="form-control" id="account_no" name="bank_details[account_no]" value="<?php echo e($record->bank_details['account_no']??''); ?>" placeholder="Enter Account No">
            <span class="msg text-danger" id="bank_details_account_no_msg"></span>
        </div>

        <div class="mb-4 col-md-4">
            <label>IFSC Code</label>
            <input type="text" class="form-control" id="ifsc_code" name="bank_details[ifsc_code]" value="<?php echo e($record->bank_details['ifsc_code']??''); ?>" placeholder="Enter IFSC Code">
            <span class="msg text-danger" id="bank_details_ifsc_code_msg"></span>
        </div>

        <div class="mb-4 col-md-4">
            <label>Account Type <span class="text-danger"><b>*</b></span></label>
            <select name="bank_details[type]" id="type" class="form-select">
                <option value="">Select</option>
                <option value="saving" <?php if(!empty($record->bank_details['type']) && $record->bank_details['type']=='saving'): echo 'selected'; endif; ?>>Saving</option>
                <option value="current" <?php if(!empty($record->bank_details['type']) && $record->bank_details['type']=='current'): echo 'selected'; endif; ?>>current</option>
                <option value="other" <?php if(!empty($record->bank_details['type']) && $record->bank_details['type']=='other'): echo 'selected'; endif; ?>>Other</option>
            </select>
            <span class="msg text-danger" id="bank_details_type_msg"></span>
        </div>

        <div class="mb-4 text-center">
            <button type="submit" class="btn btn-outline-primary" id="bankBtn">Update</button>
        </div>
    </div>
</form>

<?php $__env->startPush('script'); ?>
<script>
    $('form#saveBank').submit(function(e) {
        e.preventDefault();
        formData = new FormData(this);
        let url = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: formData,
            dataType: 'json',
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function() {
                $('#bankBtn').html(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>&nbsp;Updating...`).attr('disabled', true);
            },
            success: function(res) {
                $('#bankBtn').html('Update').removeAttr('disabled');

                /*Start Validation Error Message*/
                $('span.msg').html('');
                if (res.validation) {
                    $.each(res.validation, (index, msg) => {
                        let key = index.replace('.', '_');
                        $(`#${key}_msg`).html(`${msg}`);
                    })
                    return false;
                }
                /*End Validation Error Message*/
                /*Start Status message*/
                Swal.fire({
                    title: res.status ? 'Success' : 'Error',
                    text: res.msg,
                    icon: res.status ? 'success' : 'error'
                });
                /*End Status message*/
            }
        });
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\CRM\Profile\bankDetails.blade.php ENDPATH**/ ?>