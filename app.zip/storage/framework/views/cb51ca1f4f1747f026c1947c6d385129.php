<div class="overflow-x-auto shadow-lg">
		<table class="w-full rounded whitespace-no-wrap">
				<thead class="bg-gray-200">
						<tr>
								<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Status</th>
								<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Job</th>
								<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Details</th>
								<?php if(config('queue-monitor.ui.show_custom_data')): ?>
										<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Custom Data</th>
								<?php endif; ?>
								<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Progress</th>
								<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Queued</th>
								<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Duration</th>
								<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Started</th>
								<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Error</th>
								<?php if(config('queue-monitor.ui.allow_deletion')): ?>
										<th class="px-4 py-3 font-medium text-left text-xs text-gray-600 uppercase border-b border-gray-200">Action</th>
								<?php endif; ?>
						</tr>
				</thead>
				<tbody class="bg-white">
						<?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<?php //echo "<pre>"; print_r($job);?>
							<?php if (isset($component)) { $__componentOriginalfeef6e4d9c05202d49710fdf4a7b3bc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfeef6e4d9c05202d49710fdf4a7b3bc6 = $attributes; } ?>
<?php $component = violetshih\MongoQueueMonitor\Components\JobLine::resolve(['job' => $job,'allowDeletion' => config('queue-monitor.ui.allow_deletion'),'viewname' => $viewname] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('job-line'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(violetshih\MongoQueueMonitor\Components\JobLine::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfeef6e4d9c05202d49710fdf4a7b3bc6)): ?>
<?php $attributes = $__attributesOriginalfeef6e4d9c05202d49710fdf4a7b3bc6; ?>
<?php unset($__attributesOriginalfeef6e4d9c05202d49710fdf4a7b3bc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfeef6e4d9c05202d49710fdf4a7b3bc6)): ?>
<?php $component = $__componentOriginalfeef6e4d9c05202d49710fdf4a7b3bc6; ?>
<?php unset($__componentOriginalfeef6e4d9c05202d49710fdf4a7b3bc6); ?>
<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
										<td colspan="100" class="">
												<div class="my-6">
														<div class="text-center">
																<div class="text-gray-500 text-lg">
																		No Jobs
																</div>
														</div>
												</div>
										</td>
								</tr>
						<?php endif; ?>
				</tbody>
				<tfoot class="bg-white">
						<tr>
								<td colspan="100" class="px-6 py-4 text-gray-700 font-sm border-t-2 border-gray-200">
										<div class="flex justify-between">
												<div>
														Showing
														<?php if($jobs->total() > 0): ?>
																<span class="font-medium"><?php echo e($jobs->firstItem()); ?></span> to
																<span class="font-medium"><?php echo e($jobs->lastItem()); ?></span> of
														<?php endif; ?>
														<span class="font-medium"><?php echo e($jobs->total()); ?></span> result
												</div>
												<div>
														<a class="py-2 px-4 mx-1 text-xs font-medium <?php if(!$jobs->onFirstPage()): ?> bg-gray-200 hover:bg-gray-300 cursor-pointer <?php else: ?> text-gray-600 bg-gray-100 cursor-not-allowed <?php endif; ?> rounded"
															 <?php if(!$jobs->onFirstPage()): ?> href="<?php echo e($jobs->previousPageUrl()); ?>" <?php endif; ?>>
																Previous
														</a>
														<a class="py-2 px-4 mx-1 text-xs font-medium <?php if($jobs->hasMorePages()): ?> bg-gray-200 hover:bg-gray-300 cursor-pointer <?php else: ?> text-gray-600 bg-gray-100 cursor-not-allowed <?php endif; ?> rounded"
															 <?php if($jobs->hasMorePages()): ?> href="<?php echo e($jobs->url($jobs->currentPage() + 1)); ?>" <?php endif; ?>>
																Next
														</a>
												</div>
										</div>
								</td>
						</tr>
				</tfoot>
		</table>
</div>
<?php /**PATH D:\Users\bablu\Desktop\project\unipay\vendor\violetshih\laravel-mongo-queue-monitor\views\components\jobs-list.blade.php ENDPATH**/ ?>