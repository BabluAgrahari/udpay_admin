<div class="row">

    <div class="col-md-4">

        <strong>Branch</strong><br>

        <span><?php echo e(ucwords(str_replace('_', ' ', $record->Branch->branch_name ?? ''))); ?></span>

    </div>

    <div class="col-md-4">

        <strong>Employee</strong><br>

        <span><?php echo e(ucwords(str_replace('_', ' ', $record->Employee->basic_info['employee_name'] ?? ''))); ?></span>

    </div>

    <div class="col-md-4">

        <strong>Status</strong><br>

        <?php if($record->loan_status == 'completed'): ?>

            <span class="badge bg-label-success"><?php echo e(ucwords('Completed')); ?></span>

        <?php elseif($record->loan_status == 'on_going'): ?>

            <span class="badge bg-label-info"><?php echo e(ucwords('On Going')); ?></span>

        <?php else: ?>

            <span class="badge bg-label-warning"><?php echo e(ucwords($record->loan_status)); ?></span>

        <?php endif; ?>

    </div>

</div>



<hr>

<div class="row">

    <div class="col-md-12">

        <table class="table table-sm">

            <tr>

                <th>Loan Amount</th>

                <td><?php echo e($record->loan['loan_amount'] ?? 0); ?></td>

            <tr>

            <tr>

                <th>Interest Rate(%)</th>

                <td><?php echo e($record->loan['interest_rate'] ?? 0); ?></td>

            <tr>

            <tr>

                <th>Interest Amount</th>

                <td><?php echo e($record->loan['interest_amount'] ?? 0); ?></td>

            <tr>

            <tr>

                <th>Total Amount With Interest</th>

                <td><?php echo e($record->loan['total_amount_with_interest'] ?? 0); ?></td>

            <tr>

            <tr>

                <th>Max Tenure <small>(Month)</small></th>

                <td><?php echo e($record->loan['max_tenure'] ?? 0); ?></td>

            <tr>

            <tr>

                <th>EMI Amount</th>

                <td><?php echo e($record->loan['emi_amount'] ?? 0); ?> Month , <b>Last Month

                        EMI-</b><?php echo e($record->loan['last_emi'] ?? ''); ?></td>

            <tr>

            <tr>

                <th>Comment</th>

                <td><?php echo e($record->comment ?? ''); ?></td>

            <tr>

            <tr>

                <th>Remaning Loan Amount</th>

                <td><?php echo e($record->remaning_loan_amount ?? ''); ?></td>

            <tr>

            <tr>

                <th>EMI LEFT</th>

                <td><?php echo e($record->loan['max_tenure'] - $record->emi_count); ?></td>

            <tr>



        </table>



        <?php if(!empty($record->exist_emi)): ?>

            <h6>EMI History</h6>

            <table class="table table-sm">

                <tr>

                    <th>#</th>

                    <th>EMI Amount</th>

                    <th>Date</th>

                </tr>

                <?php $__currentLoopData = $record->exist_emi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $emi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>

                        <td><?php echo e(++$key); ?></td>

                        <td><?php echo e($emi['emi_amount'] ?? 0); ?></td>

                        <td><?php echo e(date('d M,Y', $record->date)); ?></td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

        <?php endif; ?>

    </div>

</div>

<?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\CRM\User\view.blade.php ENDPATH**/ ?>