<div class="w-full md:w-1/4 px-4 mb-4">

    <div class="h-full flex flex-col justify-between p-6 bg-white rounded shadow-md">

        <div class="font-semibold text-sm text-gray-600"
             title="Last <?php echo e(config('queue-monitor.ui.metrics_time_frame') ?? 14); ?> days">
            <?php echo e($metric->title); ?>

        </div>

        <div>

            <div class="mt-2 text-3xl">
                <?php echo e($metric->format($metric->value)); ?>

            </div>
						<div class="mt-2 text-sm">
									<?php echo e($metric->comment); ?>&nbsp;
            </div>

            <?php if($metric->previousValue !== null): ?>

                <div class="mt-2 text-sm font-semibold <?php echo e($metric->hasChanged() ? ($metric->hasIncreased() ? 'text-green-700' : 'text-red-800') : 'text-gray-800'); ?>">

                    <?php if($metric->hasChanged()): ?>
                        <?php if($metric->hasIncreased()): ?>
                            Up from
                        <?php else: ?>
                            Down from
                        <?php endif; ?>
                    <?php else: ?>
                        No change from
                    <?php endif; ?>

                    <?php echo e($metric->format($metric->previousValue)); ?>

                </div>
						<?php else: ?>
							<div class="mt-2 text-sm font-semibold }}">&nbsp;</div>
            <?php endif; ?>

        </div>

    </div>

</div>
<?php /**PATH D:\Users\bablu\Desktop\project\unipay\vendor\violetshih\laravel-mongo-queue-monitor\views\partials\metrics-card.blade.php ENDPATH**/ ?>