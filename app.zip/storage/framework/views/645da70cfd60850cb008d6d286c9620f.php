<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mongo Queue Monitor</title>
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="font-sans p-6 pb-64 bg-gray-100">
    <h1 class="mb-6 text-5xl text-blue-900 font-bold">
        Mongo Queue Monitor
    </h1>
		<?php if(config('queue-monitor.ui.show_metrics')): ?>
	    <?php if(isset($metrics)): ?>
	      <div class="flex flex-wrap -mx-4 mb-2">
	        <?php $__currentLoopData = $metrics->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if (isset($component)) { $__componentOriginal59fe25148fd01d7dd50194bf9f80d294 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59fe25148fd01d7dd50194bf9f80d294 = $attributes; } ?>
<?php $component = violetshih\MongoQueueMonitor\Components\MetricCard::resolve(['metric' => $metric] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(violetshih\MongoQueueMonitor\Components\MetricCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59fe25148fd01d7dd50194bf9f80d294)): ?>
<?php $attributes = $__attributesOriginal59fe25148fd01d7dd50194bf9f80d294; ?>
<?php unset($__attributesOriginal59fe25148fd01d7dd50194bf9f80d294); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59fe25148fd01d7dd50194bf9f80d294)): ?>
<?php $component = $__componentOriginal59fe25148fd01d7dd50194bf9f80d294; ?>
<?php unset($__componentOriginal59fe25148fd01d7dd50194bf9f80d294); ?>
<?php endif; ?>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	      </div>
	    <?php endif; ?>
		<?php endif; ?>
		<?php if (isset($component)) { $__componentOriginal1627d1068ae89a72ca2a91832db27c28 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1627d1068ae89a72ca2a91832db27c28 = $attributes; } ?>
<?php $component = violetshih\MongoQueueMonitor\Components\FiltersForm::resolve(['filters' => $filters,'queues' => $queues] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filters-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(violetshih\MongoQueueMonitor\Components\FiltersForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1627d1068ae89a72ca2a91832db27c28)): ?>
<?php $attributes = $__attributesOriginal1627d1068ae89a72ca2a91832db27c28; ?>
<?php unset($__attributesOriginal1627d1068ae89a72ca2a91832db27c28); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1627d1068ae89a72ca2a91832db27c28)): ?>
<?php $component = $__componentOriginal1627d1068ae89a72ca2a91832db27c28; ?>
<?php unset($__componentOriginal1627d1068ae89a72ca2a91832db27c28); ?>
<?php endif; ?>
		<?php if (isset($component)) { $__componentOriginal7102c82921ea936ffc9e03968d87f982 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7102c82921ea936ffc9e03968d87f982 = $attributes; } ?>
<?php $component = violetshih\MongoQueueMonitor\Components\JobsList::resolve(['jobs' => $jobs] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jobs-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(violetshih\MongoQueueMonitor\Components\JobsList::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7102c82921ea936ffc9e03968d87f982)): ?>
<?php $attributes = $__attributesOriginal7102c82921ea936ffc9e03968d87f982; ?>
<?php unset($__attributesOriginal7102c82921ea936ffc9e03968d87f982); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7102c82921ea936ffc9e03968d87f982)): ?>
<?php $component = $__componentOriginal7102c82921ea936ffc9e03968d87f982; ?>
<?php unset($__componentOriginal7102c82921ea936ffc9e03968d87f982); ?>
<?php endif; ?>
    <?php if(config('queue-monitor.ui.allow_purge')): ?>
			<?php if (isset($component)) { $__componentOriginalca5840175aaf62c4b2ae5191bed19248 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca5840175aaf62c4b2ae5191bed19248 = $attributes; } ?>
<?php $component = violetshih\MongoQueueMonitor\Components\JobPurgeForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('job-purge-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(violetshih\MongoQueueMonitor\Components\JobPurgeForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca5840175aaf62c4b2ae5191bed19248)): ?>
<?php $attributes = $__attributesOriginalca5840175aaf62c4b2ae5191bed19248; ?>
<?php unset($__attributesOriginalca5840175aaf62c4b2ae5191bed19248); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca5840175aaf62c4b2ae5191bed19248)): ?>
<?php $component = $__componentOriginalca5840175aaf62c4b2ae5191bed19248; ?>
<?php unset($__componentOriginalca5840175aaf62c4b2ae5191bed19248); ?>
<?php endif; ?>
		<?php endif; ?>
</body>
</html>
<?php /**PATH D:\Users\bablu\Desktop\project\unipay\vendor\violetshih\laravel-mongo-queue-monitor\views\jobs.blade.php ENDPATH**/ ?>