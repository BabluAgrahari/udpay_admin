<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme" style="width:13.25rem !important;">
    <div class="app-brand demo">
        <a href="<?php echo e(url('crm/dashboard')); ?>" class="app-brand-link">
            <span class="app-brand-logo demo">

                <img src="<?php echo e(user()->logo ?? ''); ?>" style="width:50%;" alt="logo">
            </span>
            <!-- <span class="app-brand-text demo menu-text fw-bold ms-2">Pay</span> -->
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm d-flex align-items-center justify-content-center"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <!-- Dashboards -->
        <li class="menu-item <?php echo e(Request::is('crm/dashboard') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('crm/dashboard')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-smile"></i>
                <div class="text-truncate" data-i18n="Email">Dashboard</div>
            </a>
        </li>


        <li class="menu-item <?php echo e(Request::is('crm/user') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('crm/user')); ?>" class="menu-link">
                <i class='menu-icon tf-icons bx bx-group'></i>
                <div class="text-truncate" data-i18n="Email">User</div>
            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
            <li class="menu-item <?php echo e(Request::is('crm/panel-users*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('crm/panel-users')); ?>" class="menu-link">
                    <i class='menu-icon tf-icons bx bx-user-check'></i>
                    <div class="text-truncate" data-i18n="Email">Panel Users</div>
                </a>
            </li>
        <?php endif; ?>

        <li
            class="menu-item <?php echo e(Request::is('crm/brands.*') || Request::is('crm/categories.*') || Request::is('crm/products.*') || Request::is('crm/units.*') || Request::is('crm/stock-history.*') ? 'open' : ''); ?>">

            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-package"></i>
                <div class="text-truncate" data-i18n="Product Management">Product Management</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item <?php echo e(Request::is('crm/categories.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/categories')); ?>" class="menu-link">
                        
                        <div class="text-truncate" data-i18n="Category">Category</div>
                    </a>
                </li>

                <li class="menu-item <?php echo e(Request::is('crm/brands.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/brands')); ?>" class="menu-link">
                       
                        <div class="text-truncate" data-i18n="Brand">Brand</div>
                    </a>
                </li>

                <li class="menu-item <?php echo e(Request::is('crm/products.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/products')); ?>" class="menu-link">
                       
                        <div class="text-truncate" data-i18n="Product">Product</div>
                    </a>
                </li>

                <li class="menu-item <?php echo e(Request::is('crm/units.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/units')); ?>" class="menu-link">
                       
                        <div class="text-truncate" data-i18n="Unit">Unit</div>
                    </a>
                </li>

                <li class="menu-item <?php echo e(Request::is('crm/stock-history.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/stock-history')); ?>" class="menu-link">
                       
                        <div class="text-truncate" data-i18n="Stock History">Stock History</div>
                    </a>
                </li>

            </ul>
        </li>

        <li class="menu-item <?php echo e(Request::is('crm/order') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('crm/order')); ?>" class="menu-link">
                <i class='menu-icon tf-icons bx bx-shopping-bag'></i>
                <div class="text-truncate" data-i18n="Order">Order</div>
            </a>
        </li>


        <li class="menu-item <?php echo e(Request::is('crm/wallet*') ? 'open' : ''); ?>">

            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-wallet"></i>
                <div class="text-truncate" data-i18n="Deals">Wallet Management</div>
            </a>
            <ul class="menu-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
                    <li class="menu-item <?php echo e(Request::is('crm/wallet/transfer') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('crm/wallet/transfer')); ?>" class="menu-link">
                            <div class="text-truncate" data-i18n="Transfer Money">Transfer Money</div>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <li class="menu-item <?php echo e(Request::is('crm/wallet/user-transfer') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/wallet/user-transfer')); ?>" class="menu-link">
                        <div class="text-truncate" data-i18n="User Transfer">Transfer Money</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(Request::is('crm/wallet/user-to-user-transfer') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/wallet/user-to-user-transfer')); ?>" class="menu-link">
                        <div class="text-truncate" data-i18n="User to User Transfer">User to User Transfer</div>
                    </a>
                </li>
                <?php endif; ?>
                
                <li class="menu-item <?php echo e(Request::is('crm/wallet/history') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/wallet/history')); ?>" class="menu-link">
                        <div class="text-truncate" data-i18n="Transfer History">Transfer History</div>
                    </a>
                </li>
            </ul>
        </li>



        <li class="menu-item <?php echo e(Request::is('crm/webhook-key') || Request::is('crm/api') || Request::is('crm/profile') || Request::is('crm/setting') || Request::is('crm/reset-password') ? 'open' : ''); ?>"
            style="">

            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-cog"></i>
                <div class="text-truncate" data-i18n="Account Settings">Account Settings</div>
            </a>
            <ul class="menu-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isMerchant')): ?>
                    <!-- <li class="menu-item <?php echo e(Request::is('crm/webhook-key') ? 'active' : ''); ?>">
                                                                    <a href="<?php echo e(url('crm/webhook-key')); ?>" class="menu-link">
                                                                        <div class="text-truncate" data-i18n="Account">Webhook & Key</div>
                                                                    </a>
                                                                </li> -->
                    <!-- <li class="menu-item <?php echo e(Request::is('crm/api') ? 'active' : ''); ?>">
                                                                    <a href="<?php echo e(url('crm/api')); ?>" class="menu-link">
                                                                        <div class="text-truncate" data-i18n="Notifications">Api</div>
                                                                    </a>
                                                                </li> -->

                    <li class="menu-item <?php echo e(Request::is('crm/profile') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('crm/profile')); ?>" class="menu-link">
                            <div class="text-truncate" data-i18n="Connections">My Account</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
                    <li class="menu-item <?php echo e(Request::is('crm/setting') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('crm/setting')); ?>" class="menu-link">
                            <div class="text-truncate" data-i18n="Connections">My Account</div>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="menu-item <?php echo e(Request::is('crm/reset-password') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('crm/reset-password')); ?>" class="menu-link">
                        <div class="text-truncate" data-i18n="Connections">Reset Password</div>
                    </a>
                </li>
            </ul>
        </li>

    </ul>
</aside>
<?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\CRM\Layout\sidebar.blade.php ENDPATH**/ ?>