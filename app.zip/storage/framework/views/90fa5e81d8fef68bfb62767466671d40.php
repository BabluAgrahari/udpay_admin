
<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <div class="card-header pt-3 pb-3">
            <div class="row">
                <div class="col-md-10">
                    <h5>Panel User Details - <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h5>
                </div>
                <div class="col-md-2 text-right">
                    <a href="<?php echo e(url('crm/panel-users')); ?>" class="btn btn-outline-warning btn-sm">
                        <i class='bx bx-left-arrow-circle'></i>&nbsp;Back
                    </a>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center">
                    <?php if($user->profile_pic): ?>
                        <img src="<?php echo e(asset($user->profile_pic)); ?>" alt="Profile Picture" class="img-fluid rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt="Default Profile" class="img-fluid rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <span class="badge bg-label-<?php echo e($user->role == 'admin' ? 'danger' : 'warning'); ?> fs-6">
                            <?php echo e(ucwords($user->role)); ?>

                        </span>
                    </div>
                    
                    <div class="mb-3">
                        <?php echo status($user->isactive); ?>

                    </div>
                </div>
                
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless table-striped">
                                <tr>
                                    <th width="30%">Full Name:</th>
                                    <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                                </tr>
                                <tr>
                                    <th>Email:</th>
                                    <td><?php echo e($user->email); ?></td>
                                </tr>
                                <tr>
                                    <th>Role:</th>
                                    <td>
                                        <span class="badge bg-label-<?php echo e($user->role == 'admin' ? 'danger' : 'warning'); ?>">
                                            <?php echo e(ucwords($user->role)); ?>

                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Status:</th>
                                    <td><?php echo status($user->isactive); ?></td>
                                </tr>
                                <tr>
                                    <th>Created On:</th>
                                    <td><?php echo e($user->dFormat($user->created)); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="30%">Address:</th>
                                    <td><?php echo e($user->address ?? 'Not provided'); ?></td>
                                </tr>
                                <tr>
                                    <th>City:</th>
                                    <td><?php echo e($user->city ?? 'Not provided'); ?></td>
                                </tr>
                                <tr>
                                    <th>State:</th>
                                    <td><?php echo e($user->state ?? 'Not provided'); ?></td>
                                </tr>
                                <tr>
                                    <th>Zip Code:</th>
                                    <td><?php echo e($user->zip_code ?? 'Not provided'); ?></td>
                                </tr>
                                <tr>
                                    <th>Last Updated:</th>
                                    <td><?php echo e($user->updated ? $user->dFormat($user->updated) : 'Not updated'); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex justify-content-end">
                        <a href="<?php echo e(url('crm/panel-users/' . $user->_id . '/edit')); ?>" class="btn btn-primary me-2">
                            <i class="bx bx-edit"></i> Edit Panel User
                        </a>
                        <a href="<?php echo e(url('crm/panel-users/' . $user->_id . '/change-password')); ?>" class="btn btn-warning me-2">
                            <i class="bx bx-key"></i> Change Password
                        </a>
                        <button type="button" class="btn btn-danger" onclick="deleteUser('<?php echo e($user->_id); ?>')">
                            <i class="bx bx-trash"></i> Delete
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
<script>
    function deleteUser(userId) {
        if (confirm('Are you sure you want to delete this panel user? This action cannot be undone.')) {
            $.ajax({
                url: "<?php echo e(url('crm/panel-users')); ?>/" + userId,
                type: 'DELETE',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.status) {
                        alertMsg(response.status, response.msg, 3000);
                        setTimeout(function() {
                            window.location.href = "<?php echo e(url('crm/panel-users')); ?>";
                        }, 1000);
                    } else {
                        alertMsg(false, response.msg, 3000);
                    }
                },
                error: function() {
                    alertMsg(false, xhr.responseJSON.msg, 3000);
                }
            });
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('CRM.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\CRM\PanelUser\show.blade.php ENDPATH**/ ?>