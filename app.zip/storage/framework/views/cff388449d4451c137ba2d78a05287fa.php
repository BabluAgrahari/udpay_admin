<form action="<?php echo e(url('crm/categories')); ?>" method="GET" class="mb-4">
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label for="search">Search</label>
                <input type="text" 
                       name="search" 
                       id="search" 
                       class="form-control" 
                       value="<?php echo e(request('search')); ?>" 
                       placeholder="Search by name or description">
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="form-group">
                <label for="status">Status</label>
                <select name="status" id="status" class="form-control">
                    <option value="">All</option>
                    <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>Active</option>
                    <option value="0" <?php echo e(request('status') == '0' ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="form-group">
                <label for="parent_id">Parent Category</label>
                <select name="parent_id" id="parent_id" class="form-control">
                    <option value="">All</option>
                    <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($parent->_id); ?>" 
                                <?php echo e(request('parent_id') == $parent->_id ? 'selected' : ''); ?>>
                            <?php echo e($parent->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="form-group">
                <label>&nbsp;</label>
                <div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Filter
                    </button>
                    <a href="<?php echo e(url('crm/categories')); ?>" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset
                    </a>
                </div>
            </div>
        </div>
    </div>
</form> <?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\CRM\category\filter.blade.php ENDPATH**/ ?>