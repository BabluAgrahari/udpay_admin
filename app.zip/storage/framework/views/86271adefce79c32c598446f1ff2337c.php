<div class="mt-12">
		<form action="<?php echo e(route('queue-monitor::purge', [ 'viewname' => $viewname])); ?>" method="post">
				<?php echo csrf_field(); ?>
				<?php echo method_field('delete'); ?>
				<button class="px-3 py-1 bg-red-200 hover:bg-red-300 text-red-800 text-xs font-medium uppercase tracking-wider text-white rounded">
						Delete all entries
				</button>
		</form>
</div>
<?php /**PATH D:\Users\bablu\Desktop\project\unipay\vendor\violetshih\laravel-mongo-queue-monitor\views\components\job-purge-form.blade.php ENDPATH**/ ?>