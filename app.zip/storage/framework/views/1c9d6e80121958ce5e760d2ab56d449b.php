<div class="row">
    <?php

    use Illuminate\Http\Request;

    $perPage = (!empty($_GET['perPage'])) ? (int)$_GET['perPage'] : config('constants.perPage'); ?>
    <div class="col-md-2 is-5 mt-3">
        <select class="form-select-sm form-select" name="perPare" id="perPage">
            <!-- <option value="10" <?php echo e(($perPage =="10" )?"selected":""); ?>>10</option> -->
            <option value="20" <?php echo e(($perPage =="20" )?'selected':''); ?>>20</option>
            <option value="50" <?php echo e(($perPage =="50" )?'selected':''); ?>>50</option>
            <option value="100" <?php echo e(($perPage =="100" )?'selected':''); ?>>100</option>
            <option value="200" <?php echo e(($perPage =="200" )?'selected':''); ?>>200</option>
            <option value="500" <?php echo e(($perPage =="500" )?'selected':''); ?>>500</option>
        </select>
    </div>
    <div class="col-md-4 is-5 mt-4">
        <?php
        $perPage = (!empty($_GET['perPage'])) ? (int)$_GET['perPage'] : config('constants.perPage');
        $first_record = $paginator->firstItem();
        $current_record = ($perPage * ($paginator->currentPage() - 1)) + $paginator->count();
        $total_record = $paginator->total();

        echo "Showing $first_record to  $current_record of $total_record Results.";

        ?>
    </div>
    <?php if($paginator->hasPages()): ?>
    <div class="col-md-6 mt-3">
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-end">

                <?php if($paginator->onFirstPage()): ?>
                <li class="disabled page-item first"><span class="page-link"><i class="tf-icon bx bx-chevrons-left bx-sm"></i></span></li>
                <?php else: ?>
                <li class="page-item first"><a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page-link" rel="prev"><i class="tf-icon bx bx-chevrons-left bx-sm"></i></a></li>
                <?php endif; ?>


                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(is_string($element)): ?>
                <li class="disabled page-item first"><span><?php echo e($element); ?></span></li>
                <?php endif; ?>


                <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                <li class="active my-active page-item"><span class="page-link"><?php echo e($page); ?></span></li>
                <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php if($paginator->hasMorePages()): ?>
                <li class="page-item last"><a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><i class="tf-icon bx bx-chevrons-right bx-sm"></i></a></li>
                <?php else: ?>
                <li class="disabled page-item last"><span class="page-link"><i class="tf-icon bx bx-chevrons-right bx-sm"></i></span></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>

    <?php endif; ?>
</div>
<?php $__env->startPush('custom-script'); ?>
<?php
$x = $_SERVER['REQUEST_URI'];
$parsed = parse_url($x);
$string = '';
if (!empty($parsed['query'])) {
    $query = $parsed['query'];
    parse_str($query, $params);
    unset($params['perPage']);
    $string = http_build_query($params);
}
?>
<script>
    $('#perPage').change(function() {
        var query = '<?= $string ?>';
        var perPage = $(this).val();
        location.href = "<?php echo e(url()->current()); ?>?perPage=" + perPage + '&' + query;
    })
</script>

<?php $__env->stopPush(); ?><?php /**PATH D:\Users\bablu\Desktop\project\unipay\resources\views\Pagination.blade.php ENDPATH**/ ?>